global.pitchAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngle = 0.0;
global.yawAngleO = 0.0;

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

local physicsItems = {
    "minecraft:elytra"
}

for _, physicsItem in ipairs(physicsItems) do
    if I:isOf(item, Items:get(physicsItem)) then
        M:moveY(matrices, 0.25)
        M:moveZ(matrices, -0.05)
    end
end