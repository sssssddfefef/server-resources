-- Cyber, GreatKingKeenan and Axolotl were here :3

local l = context.bl and 1 or -1
local d = (context.bl and 1) or -0.43
local a = (context.bl and 1) or 0.8


renderAsBlock:put("minecraft:pointed_dripstone", false)
renderAsBlock:put("minecraft:small_amethyst_bud", false)
renderAsBlock:put("minecraft:medium_amethyst_bud", false)
renderAsBlock:put("minecraft:large_amethyst_bud", false)
renderAsBlock:put("minecraft:amethyst_cluster", false)
renderAsBlock:put("minecraft:resin_clump", false)

-- Named Variants
if ( 
	not string.find(I:getActualName(context.item), "Display Case")
) then

-- Iron Ingot, Copper Ingot, Gold Ingot, Netherite Ingot, Brick, Resin Brick, Nether Brick
if (
	I:isOf(context.item, Items:get("minecraft:iron_ingot")) or
	I:isOf(context.item, Items:get("minecraft:copper_ingot")) or
	I:isOf(context.item, Items:get("minecraft:gold_ingot")) or
	I:isOf(context.item, Items:get("minecraft:netherite_ingot")) or
	I:isOf(context.item, Items:get("minecraft:brick")) or
	I:isOf(context.item, Items:get("minecraft:resin_brick")) or
	I:isOf(context.item, Items:get("minecraft:nether_brick"))
) then
	M:moveY(context.matrices, 0.1)
	M:moveX(context.matrices, -0.05 * l)
	M:moveZ(context.matrices, 0.15)
	
	M:rotateX(context.matrices, 0)
	M:rotateY(context.matrices, -30 * l)
	M:rotateZ(context.matrices, 90 * l)

	M:scale(context.matrices, 1.1, 1.1, 1.1)
end

-- Ingots
if  (
	string.find(I:getActualName(context.item), "Ingots")
) then
	M:moveY(context.matrices, 0)
	M:moveX(context.matrices, 0.05 * l)
	M:moveZ(context.matrices, 0)
	
	M:rotateX(context.matrices, 0)
	M:rotateY(context.matrices, 0 * l)
	M:rotateZ(context.matrices, 0 * l)
end

-- Lapis Lazuli
if I:isOf(context.item, Items:get("minecraft:lapis_lazuli"))
then
	M:moveY(context.matrices, 0.2)
	M:moveZ(context.matrices, 0.1)
	M:moveX(context.matrices, -0.025 * l)
	
	M:rotateX(context.matrices, -270)
	M:rotateY(context.matrices, -180 * l)
end

-- Emerald
if I:isOf(context.item, Items:get("minecraft:emerald")) then
	M:moveY(context.matrices, 0.2)
	M:moveZ(context.matrices, 0.18)
	M:moveX(context.matrices, 0)
	
	M:rotateY(context.matrices, 93 * l)
	M:rotateX(context.matrices, -50)
	M:rotateZ(context.matrices, -30 * l)
	
	M:scale(context.matrices, 1.3, 1.3, 1.3)
end

-- Ruby
if  (
	string.find(I:getActualName(context.item), "Ruby")
) then
	M:moveY(context.matrices, 0)
	M:moveX(context.matrices, -0.1 * l)
	M:moveZ(context.matrices, 0)
	
	M:rotateX(context.matrices, 0)
	M:rotateY(context.matrices, 0 * l)
	M:rotateZ(context.matrices, 0 * l)
end

-- Amethyst Shard, Echo Shard
if (
	I:isOf(context.item, Items:get("minecraft:amethyst_shard")) or
	I:isOf(context.item, Items:get("minecraft:echo_shard"))
) then
	M:moveY(context.matrices, 0.05)
	M:moveZ(context.matrices, 0)
	M:moveX(context.matrices, 0)

	M:rotateY(context.matrices, 0)
	M:rotateX(context.matrices, -40)
	M:rotateZ(context.matrices, 0)
	
	M:scale(context.matrices, 1.5, 1.5, 1.5)
end

-- Coal, Charcoal
if (
	I:isOf(context.item, Items:get("minecraft:coal")) or
	I:isOf(context.item, Items:get("minecraft:charcoal"))
) then
	M:moveY(context.matrices, 0.1)
	M:moveZ(context.matrices, 0.15)
	M:moveX(context.matrices, 0)

	M:rotateY(context.matrices, 160 * l)
	M:rotateX(context.matrices, -50)
	M:rotateZ(context.matrices, 0)
	
	M:scale(context.matrices, 1.3, 1.3, 1.3)
end

-- Netherite Scrap
if I:isOf(context.item, Items:get("minecraft:netherite_scrap")) then
	M:moveY(context.matrices, 0.1)
	M:moveZ(context.matrices, 0.15)
	M:moveX(context.matrices, -0.1 * l)

	M:rotateY(context.matrices, -90 * l)
	M:rotateX(context.matrices, 13)
	M:rotateZ(context.matrices, 90 * l)
	
	M:scale(context.matrices, 1.2, 1.2, 1.2)
end

-- Iron Nugget, Copper Nugget, Gold Nugget
if (
	I:isOf(context.item, Items:get("minecraft:iron_nugget")) or
	I:isOf(context.item, Items:get("minecraft:gold_nugget")) or
	I:isOf(context.item, Items:get("minecraft:copper_nugget"))
) then
	M:moveX(context.matrices, -0.05 * l)
	M:moveY(context.matrices, 0.15)
	M:moveZ(context.matrices, 0.1)
	
	M:rotateX(context.matrices, 0)
	
	M:scale(context.matrices, 1.3, 1.3, 1.3)
end

-- Gold Coin
if  (
	string.find(I:getActualName(context.item), "Coin")
) then
	M:moveY(context.matrices, -0.025)
	M:moveX(context.matrices, 0 * l)
	M:moveZ(context.matrices, -0.05)
	
	M:rotateX(context.matrices, 0)
	M:rotateY(context.matrices, 0 * l)
	M:rotateZ(context.matrices, 0 * l)

	M:scale(context.matrices, 0.7, 0.7, 0.7)
end

-- Redstone
if (
	I:isOf(context.item, Items:get("minecraft:redstone")) 
) then
	M:moveY(context.matrices, 0.09)
	M:moveZ(context.matrices, 0.25)
	M:moveX(context.matrices, -0.05 * l)
	
	M:rotateX(context.matrices, -45)

	M:scale(context.matrices, 1.3, 1.3, 1.3)

	I:setTranslate(context.item, false)
    
    particleManager:addParticle(
        context.particles, 
        false, 
        0 * l, 
        0.025, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        1.1, 
        Texture:of("minecraft", "textures/particle/redstone_glow.png"), 
        "ITEM", 
        context.hand, 
        "SPAWN", 
        "ADDITIVE", 
        0, 
        200 + (20 * M:sin(P:getAge(context.player) * 0.2))
    )
end

-- Flint
if I:isOf(context.item, Items:get("minecraft:flint")) then
	M:moveY(context.matrices, 0.1)
	M:moveZ(context.matrices, 0.1)
	
	M:rotateY(context.matrices, 93 * l)
	M:rotateX(context.matrices, -50)
	M:rotateZ(context.matrices, -30 * l)
	
	M:scale(context.matrices, 1.5, 1.5, 1.5)
end

-- Raw Iron, Raw Copper, Raw Gold
if (
	I:isOf(context.item, Items:get("minecraft:raw_iron")) or
	I:isOf(context.item, Items:get("minecraft:raw_copper")) or
	I:isOf(context.item, Items:get("minecraft:raw_gold"))
) then
	M:moveY(context.matrices, 0.1)
	M:moveZ(context.matrices, 0.15)
	M:moveX(context.matrices, 0)

	M:rotateY(context.matrices, 160 * l)
	M:rotateX(context.matrices, -50)
	M:rotateZ(context.matrices, 0)

	M:scale(context.matrices, 1.2, 1.2, 1.2)
end

-- Resin Clump
if (
	I:isOf(context.item, Items:get("minecraft:resin_clump"))
) then
	M:moveY(context.matrices, 0)
	M:moveZ(context.matrices, 0.1)
	M:moveX(context.matrices, 0 * l)
	
	M:rotateY(context.matrices, -20)

	M:scale(context.matrices, 1.2, 1.2, 1.2)
end

-- Small Amethyst Bud, Medium Amethyst Bud, Large Amethyst Bud, Amethyst Cluster, Quartz
if (
	I:isOf(context.item, Items:get("minecraft:small_amethyst_bud")) or
	I:isOf(context.item, Items:get("minecraft:medium_amethyst_bud")) or
	I:isOf(context.item, Items:get("minecraft:large_amethyst_bud")) or
	I:isOf(context.item, Items:get("minecraft:quartz")) or
	I:isOf(context.item, Items:get("minecraft:amethyst_cluster"))
) then
	M:moveY(context.matrices, 0.05)
	M:moveZ(context.matrices, -0.05)
	M:moveX(context.matrices, 0 * l)
	
	M:rotateY(context.matrices, 0)
end

-- Pointed Dripstone
if (
	I:isOf(context.item, Items:get("minecraft:pointed_dripstone"))
) then
	M:moveY(context.matrices, 0.15)
	M:moveZ(context.matrices, 0.075)
	M:moveX(context.matrices, -0.1 * l)
	
	M:rotateY(context.matrices, 0)
	M:rotateZ(context.matrices, 0)
	M:rotateX(context.matrices, 140)

	M:scale(context.matrices, 1.1, 1.1, 1.1)
end

-- Diamond

if I:isOf(context.item, Items:get("minecraft:diamond")) then
    M:moveY(context.matrices, 0.2)
    M:moveZ(context.matrices, 0.1) 
    M:moveX(context.matrices, 0) 

    M:rotateY(context.matrices, 93 * l)
    M:rotateX(context.matrices, -50)
    M:rotateZ(context.matrices, -30 * l)
    M:scale(context.matrices, 1.3, 1.3, 1.3)
end
end
